document.querySelectorAll('button.sil').forEach(el => {
    el.onclick = () => deleteItem(el)
});
function deleteItem(e) {
    e.parentElement.remove()
}
document.querySelector('#push').onclick = function () {
    if (document.querySelector('#newtask input').value.length == 0) {
        alert("Пожалуйста, введите название задачи!")
    }
    else {
        document.querySelector('#tasks').innerHTML += `
            <div class="task">
                <span id="taskname">
                    ${document.querySelector('#newtask input').value}
            </div>
        `;
    }
}
function sort() {
    let sort, i, run, li, stop;
    sort = document.getElementById("srt");
    run = true;
    while (run) {
        run = false;
        li = sort.getElementsByTagName("LI");
        for (i = 0; i < (li.length - 1); i++) {
            stop = false;
            if (li[i].innerHTML.toLowerCase() >
                li[i + 1].innerHTML.toLowerCase()) {
                stop = true;
                break;
            }
        }
        if (stop) {
            li[i].parentNode.insertBefore(
                li[i + 1], li[i]);
            run = true;
        }
    }
}
